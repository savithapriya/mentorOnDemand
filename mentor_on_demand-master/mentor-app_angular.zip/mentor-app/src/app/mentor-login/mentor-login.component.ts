import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import{ MentorSignInServiceService} from '../shared/mentor-sign-in-service.service'
import { UserSignUp } from '../shared/user-sign-up';
import{ MentorSignUp} from '../shared/mentor-sign-up';
import { MentorSignUpServiceService } from '../shared/mentor-sign-up-service.service';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';
import { LoginDetails } from '../shared/login-details';

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {

  loginDetails:LoginDetails=new LoginDetails();
  mentorLoginForm:FormGroup;
  mentorSignUpForm:FormGroup;
  submitted=false;
  
  constructor(private route: ActivatedRoute, private router: Router, private mentorService: MentorSignUpServiceService,private formBuilder:FormBuilder,private mentorSignInService: MentorSignInServiceService) {}
  mentorSignUp:MentorSignUp=new MentorSignUp();
   
   ngOnInit() {
    this.mentorSignUpForm=this.formBuilder.group(
      {
      formFirstname:['',Validators.required],
      formlastname:['',Validators.required],
      formemail:['',Validators.required],
      formpassword:['',Validators.required],

    });
    this.mentorLoginForm=this.formBuilder.group({
      formusername:['',Validators.required],
      formpassword:['',Validators.required]
    })
  
  }

  get f(){ return this.mentorSignUpForm.controls;}

 
    onSubmit(){
       this.submitted=true;
       this.mentorSignUp.firstname=this.mentorSignUpForm.get('formFirstname').value;
       this.mentorSignUp.lastname=this.mentorSignUpForm.get('formlastname').value;
       this.mentorSignUp.email=this.mentorSignUpForm.get('formemail').value;
       this.mentorSignUp.password=this.mentorSignUpForm.get('formpassword').value;
       this.mentorService.createUser(this.mentorSignUp).subscribe(data => console.log(data),error=>console.log(error));
       this.router.navigate(['/mentor-home']);
    }

    onSubmitMentor(){
      this.mentorSignInService.mentorLogin(this.mentorLoginForm.get("formusername").value).subscribe(
      data=>{
        this.loginDetails=data;
        if(this.mentorLoginForm.get("formpassword").value==this.loginDetails.password){
          console.log("Success");
          this.router.navigateByUrl("/mentor-home");
        }
        else{
          console.log("Fail");
          alert("Incorrect Credentials");
        }
      });
    }
}
