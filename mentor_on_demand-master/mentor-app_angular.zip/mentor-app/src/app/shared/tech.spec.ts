import { Tech } from './tech';

describe('Tech', () => {
  it('should create an instance', () => {
    expect(new Tech()).toBeTruthy();
  });
});
