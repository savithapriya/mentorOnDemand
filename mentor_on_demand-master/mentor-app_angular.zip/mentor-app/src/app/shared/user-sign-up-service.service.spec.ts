import { TestBed } from '@angular/core/testing';

import { UserSignUpServiceService } from './user-sign-up-service.service';

describe('UserSignUpServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserSignUpServiceService = TestBed.get(UserSignUpServiceService);
    expect(service).toBeTruthy();
  });
});
