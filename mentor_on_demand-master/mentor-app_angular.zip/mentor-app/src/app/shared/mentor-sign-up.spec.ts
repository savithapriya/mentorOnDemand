import { MentorSignUp } from './mentor-sign-up';

describe('MentorSignUp', () => {
  it('should create an instance', () => {
    expect(new MentorSignUp()).toBeTruthy();
  });
});
