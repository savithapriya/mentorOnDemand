import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginDetails } from './login-details';

@Injectable({
  providedIn: 'root'
})
export class UserSignInServiceService {

  constructor(private http:HttpClient) { }
  userLogin(user:string):Observable<LoginDetails>{
    return this.http.get<LoginDetails>('http://localhost:8045/trainee/userName/'+user);
} 


}
