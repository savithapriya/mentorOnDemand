import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginDetails } from './login-details';

@Injectable({
  providedIn: 'root'
})
export class MentorSignInServiceService {

  constructor(private http:HttpClient) { }
  mentorLogin(user:string):Observable<LoginDetails>{
    return this.http.get<LoginDetails>('http://localhost:8045/trainer/userName/'+user);
  }
}
