import { UserSignUp } from './user-sign-up';

describe('UserSignUp', () => {
  it('should create an instance', () => {
    expect(new UserSignUp()).toBeTruthy();
  });
});
