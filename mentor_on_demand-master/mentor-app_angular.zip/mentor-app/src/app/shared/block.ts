export class Block {
    firstname: string;
    lastname: string;

    email: string;
    password: string;
}
