import { TestBed } from '@angular/core/testing';

import { MentorSignUpServiceService } from './mentor-sign-up-service.service';

describe('MentorSignUpServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorSignUpServiceService = TestBed.get(MentorSignUpServiceService);
    expect(service).toBeTruthy();
  });
});
