import { TestBed } from '@angular/core/testing';

import { MentorSignInServiceService } from './mentor-sign-in-service.service';

describe('MentorSignInServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorSignInServiceService = TestBed.get(MentorSignInServiceService);
    expect(service).toBeTruthy();
  });
});
