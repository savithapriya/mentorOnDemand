export class MentorSignUp {
    firstname: string;
    lastname: string;

    email: string;
    password: string;
}
