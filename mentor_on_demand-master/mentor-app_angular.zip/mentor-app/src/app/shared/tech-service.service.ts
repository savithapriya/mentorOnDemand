import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MentorSignUp } from './mentor-sign-up';


@Injectable({
  providedIn: 'root'
})
export class TechServiceService {

  private baseUrl = 'http://localhost:8045/';  
  constructor(private http:HttpClient) { }
  createTech(Tech:Object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`+'admin/admin/tech',Tech);
  }
}
