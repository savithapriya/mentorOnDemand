import { TestBed } from '@angular/core/testing';

import { UserSignInServiceService } from './user-sign-in-service.service';

describe('UserSignInServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserSignInServiceService = TestBed.get(UserSignInServiceService);
    expect(service).toBeTruthy();
  });
});
