export class UserSignUp {
    firstname: string;
    lastname: string;

    email: string;
    password: string;
}
