export class Tech {
    name: string;
    duration: string;
    about: string;
    

}
