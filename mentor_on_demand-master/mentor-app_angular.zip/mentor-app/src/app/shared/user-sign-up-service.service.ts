import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserSignUp } from './user-sign-up';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class UserSignUpServiceService {
  private baseUrl = 'http://localhost:8045/';  
  
  constructor(private http:HttpClient) { }  
  createUser(UserSignUp:Object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`+'trainee/trainee-signup',UserSignUp);
  }
  
  
}
