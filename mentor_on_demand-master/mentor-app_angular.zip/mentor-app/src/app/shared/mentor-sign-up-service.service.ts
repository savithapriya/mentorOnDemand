import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MentorSignUp } from './mentor-sign-up';


@Injectable({
  providedIn: 'root'
})
export class MentorSignUpServiceService {
  
  private baseUrl = 'http://localhost:8045/';  
  
  constructor(private http:HttpClient) { }  
  createUser(MentorSignUp:Object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`+'trainer/trainer-signup',MentorSignUp);
  }
}
