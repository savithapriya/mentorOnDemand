export class LoginDetails {
    username:string;
    password:string;
}
