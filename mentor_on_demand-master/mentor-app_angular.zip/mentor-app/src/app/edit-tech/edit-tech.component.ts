import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-tech',
  templateUrl: './edit-tech.component.html',
  styleUrls: ['./edit-tech.component.css']
})
export class EditTechComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
