import { Component, OnInit } from '@angular/core';
import { Tech } from '../shared/tech';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import{TechServiceService} from '../shared/tech-service.service';

@Component({
  selector: 'app-add-tech',
  templateUrl: './add-tech.component.html',
  styleUrls: ['./add-tech.component.css']
})
export class AddTechComponent implements OnInit {
 
  addTechForm:FormGroup;
  
  submitted=false;

  constructor(private route: ActivatedRoute, private router: Router, private techService: TechServiceService,private formBuilder:FormBuilder) { }
  tech:Tech=new Tech();
  ngOnInit() {
    this.addTechForm=this.formBuilder.group({
      techname:['',Validators.required],
      duration:['',Validators.required],
      about:['',Validators.required]
    })
  }
  get f(){ return this.addTechForm.controls;}

 
    onSubmit(){
       this.submitted=true;
       this.tech.name=this.addTechForm.get('techname').value;
       this.tech.duration=this.addTechForm.get('duration').value;
       this.tech.about=this.addTechForm.get('about').value;

       this.addTech;
       this.router.navigate(['/admin-page']);
    }

     addTech(event) { 
      //just added console.log which will display the event details in browser on click of the button.
      alert("Added Successfully!!!!");
      console.log(event);
   }


}
