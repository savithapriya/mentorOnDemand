import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import{ UserSignInServiceService} from '../shared/user-sign-in-service.service'
import { UserSignUp } from '../shared/user-sign-up';
import { UserSignUpServiceService } from '../shared/user-sign-up-service.service';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';
import { LoginDetails } from '../shared/login-details';


import { from } from 'rxjs';
import { error } from 'util';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {  

  loginDetails:LoginDetails=new LoginDetails();
  userSignUpForm:FormGroup;
  userLoginForm:FormGroup;
  submitted=false;
  
  constructor(private route: ActivatedRoute, private router: Router, private userService: UserSignUpServiceService,private formBuilder:FormBuilder,private userSignInServiceService:UserSignInServiceService) {}
   usersignup:UserSignUp=new UserSignUp();
   
   ngOnInit() {
    this.userSignUpForm=this.formBuilder.group(
      {
      formFirstname:['',Validators.required],
      formlastname:['',Validators.required],
      formemail:['',Validators.required],
      formpassword:['',Validators.required],

    });
    this.userLoginForm=this.formBuilder.group({
      formusername:['',Validators.required],
      formpassword:['',Validators.required]
    });
  
  }

  get f(){ return this.userSignUpForm.controls;}
  get g(){ return this.userLoginForm.controls;}


 
    onSubmit(){
       this.submitted=true;
       this.usersignup.firstname=this.userSignUpForm.get('formFirstname').value;
       this.usersignup.lastname=this.userSignUpForm.get('formlastname').value;
       this.usersignup.email=this.userSignUpForm.get('formemail').value;
       this.usersignup.password=this.userSignUpForm.get('formpassword').value;
       this.userService.createUser(this.usersignup).subscribe(data => console.log(data),error=>console.log(error));
       this.router.navigate(['/user-home']);
    }

    onSubmitUser(){
      this.userSignInServiceService.userLogin(this.userLoginForm.get("formusername").value).subscribe(
      data=>{
        this.loginDetails=data;
        if(this.userLoginForm.get("formpassword").value==this.loginDetails.password){
          console.log("Success");
          this.router.navigateByUrl("/user-home");
        }
        else{
          console.log("Fail");
          alert("Incorrect Credentials");
        }
      });
    }
  
  }


