import { Component, OnInit } from '@angular/core';
import { AdminService } from '../shared/admin.service';
import { LoginDetails } from '../shared/login-details';
import{Router} from '@angular/router';

import { FormGroup,FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css'],
  providers:[AdminService]
})
export class AdminLoginComponent implements OnInit {

  loginDetails:LoginDetails=new LoginDetails();
  adminLoginForm:FormGroup;

  constructor(private adminService:AdminService,private formBuilder:FormBuilder, private router: Router) { }

  ngOnInit() {
    this.adminLoginForm=this.formBuilder.group({
      formusername:['',Validators.required],
      formpassword:['',Validators.required]
    })
  }
  onSubmit(){
    this.adminService.adminLogin(this.adminLoginForm.get("formusername").value).subscribe(
    data=>{
      this.loginDetails=data;
      if(this.adminLoginForm.get("formpassword").value==this.loginDetails.password){
        console.log("Success");
        this.router.navigateByUrl("/admin-page");
      }
      else{
        console.log("Fail");
        alert("Incorrect Credentials");
      }
    });
  

}
}
