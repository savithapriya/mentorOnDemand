import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { TrainingProgressComponent } from './training-progress/training-progress.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PaymentComponent } from './payment/payment.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { EditTechComponent } from './edit-tech/edit-tech.component';
import { FeeEditComponent } from './fee-edit/fee-edit.component';
import { AddTechComponent } from './add-tech/add-tech.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { EditTechPageComponent } from './edit-tech-page/edit-tech-page.component';
import { MentorHomeComponent } from './mentor-home/mentor-home.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { ProposalStatusComponent } from './proposal-status/proposal-status.component';
import { NotificationUserComponent } from './notification-user/notification-user.component';
import { BlockComponent } from './block/block.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CompleteTrainingUserComponent } from './complete-training-user/complete-training-user.component';
import { TrainingInProgressUserComponent } from './training-in-progress-user/training-in-progress-user.component';
import { PaymentUserComponent } from './payment-user/payment-user.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [
    AppComponent,
    TrainingProgressComponent,
    UserHomeComponent,
    TransactionComponent,
    PaymentComponent,
    CompletedTrainingComponent,
    HomePageComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminPageComponent,
    EditTechComponent,
    FeeEditComponent,
    AddTechComponent,
    EditProfileComponent,
    EditTechPageComponent,
    MentorHomeComponent,
    MentorprofileComponent,
    ProposalStatusComponent,
    NotificationUserComponent,
    BlockComponent,
    AdminLoginComponent,
    CompleteTrainingUserComponent,
    TrainingInProgressUserComponent,
    PaymentUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
