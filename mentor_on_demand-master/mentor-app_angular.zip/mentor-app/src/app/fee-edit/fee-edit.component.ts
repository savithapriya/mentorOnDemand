import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fee-edit',
  templateUrl: './fee-edit.component.html',
  styleUrls: ['./fee-edit.component.css']
})
export class FeeEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
