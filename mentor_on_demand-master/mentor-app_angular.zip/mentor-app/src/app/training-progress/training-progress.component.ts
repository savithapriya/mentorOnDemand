import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-progress',
  templateUrl: './training-progress.component.html',
  styleUrls: ['./training-progress.component.css']
})
export class TrainingProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
