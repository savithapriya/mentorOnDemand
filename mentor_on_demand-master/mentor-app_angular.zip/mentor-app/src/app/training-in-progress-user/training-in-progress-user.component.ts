import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-training-in-progress-user',
  templateUrl: './training-in-progress-user.component.html',
  styleUrls: ['./training-in-progress-user.component.css']
})
export class TrainingInProgressUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
