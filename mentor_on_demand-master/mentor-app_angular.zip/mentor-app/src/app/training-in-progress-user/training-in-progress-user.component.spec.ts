import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainingInProgressUserComponent } from './training-in-progress-user.component';

describe('TrainingInProgressUserComponent', () => {
  let component: TrainingInProgressUserComponent;
  let fixture: ComponentFixture<TrainingInProgressUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainingInProgressUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainingInProgressUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
