import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import{BlockServiceService} from '../shared/block-service.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import{Block} from '../shared/block';

@Component({
  selector: 'app-block',
  templateUrl: './block.component.html',
  styleUrls: ['./block.component.css']
})
export class BlockComponent implements OnInit {
  users: Observable<Block[]>;

  constructor(private searchService: BlockServiceService, private httpService:HttpClient) {}

  search1:Block[];
  ngOnInit() {
    this.searchService.findAll().subscribe(data => {
      this.search1=data;
    });
    this.reloadData();
  }
  reloadData() {
    this.searchService.findAll().subscribe(data =>{
      this.search1=data;
    });
    this.users = this.searchService.findAll();
  }

  deletementor(id: number) {
    this.searchService.deletementor(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

}
