import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complete-training-user',
  templateUrl: './complete-training-user.component.html',
  styleUrls: ['./complete-training-user.component.css']
})
export class CompleteTrainingUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
