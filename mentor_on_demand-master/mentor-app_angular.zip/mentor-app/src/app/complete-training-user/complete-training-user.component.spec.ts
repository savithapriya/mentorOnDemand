import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteTrainingUserComponent } from './complete-training-user.component';

describe('CompleteTrainingUserComponent', () => {
  let component: CompleteTrainingUserComponent;
  let fixture: ComponentFixture<CompleteTrainingUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteTrainingUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteTrainingUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
