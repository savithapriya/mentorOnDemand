import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-tech-page',
  templateUrl: './edit-tech-page.component.html',
  styleUrls: ['./edit-tech-page.component.css']
})
export class EditTechPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  addTech(event) { 
    //just added console.log which will display the event details in browser on click of the button.
    alert("Edited Successfully!!!!");
    console.log(event);
 }
}
