import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTechPageComponent } from './edit-tech-page.component';

describe('EditTechPageComponent', () => {
  let component: EditTechPageComponent;
  let fixture: ComponentFixture<EditTechPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTechPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTechPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
