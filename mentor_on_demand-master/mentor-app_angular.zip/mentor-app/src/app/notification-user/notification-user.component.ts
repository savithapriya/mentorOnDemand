import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-user',
  templateUrl: './notification-user.component.html',
  styleUrls: ['./notification-user.component.css']
})
export class NotificationUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
