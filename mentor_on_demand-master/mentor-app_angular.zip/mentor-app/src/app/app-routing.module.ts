import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TrainingProgressComponent } from './training-progress/training-progress.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PaymentComponent } from './payment/payment.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { EditTechComponent } from './edit-tech/edit-tech.component';
import { FeeEditComponent } from './fee-edit/fee-edit.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { EditTechPageComponent } from './edit-tech-page/edit-tech-page.component';
import { AddTechComponent } from './add-tech/add-tech.component';
import { MentorHomeComponent } from './mentor-home/mentor-home.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { ProposalStatusComponent } from './proposal-status/proposal-status.component';
import { NotificationUserComponent } from './notification-user/notification-user.component';
import { BlockComponent } from './block/block.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { CompleteTrainingUserComponent } from './complete-training-user/complete-training-user.component';
import { TrainingInProgressUserComponent } from './training-in-progress-user/training-in-progress-user.component';
import { PaymentUserComponent } from './payment-user/payment-user.component';

const routes: Routes = [
  {
    path:'',
    component: HomePageComponent
  },
  {
    path:'home-page',
    component: HomePageComponent
  },

  {
    path:'training-progress',
    component: TrainingProgressComponent
  },
  {
    path:'user-home',
    component: UserHomeComponent
  },
  {
    path:'transaction',
    component: TransactionComponent
  },
  {
    path:'payment',
    component: PaymentComponent
  },
  {
    path:'completed-training',
    component: CompletedTrainingComponent
  },
  
  {
    path:'mentor-login',
    component: MentorLoginComponent
  },
  {
    path:'user-login',
    component: UserLoginComponent
  },
  {
    path:'admin-page',
    component: AdminPageComponent
  },
  {
    path:'edit-profile',
    component: EditProfileComponent
  },
  {
    path:'edit-tech',
    component: EditTechComponent
  },
  {
    path:'edit-tech-page',
    component: EditTechPageComponent
  },
  {
    path:'add-tech',
    component: AddTechComponent
  },
  {
    path:'mentor-home',
    component:  MentorHomeComponent
  },

  {
    path:'mentorprofile',
    component: MentorprofileComponent
  },
  {
    path:'proposal-status',
    component: ProposalStatusComponent
  },
  {
    path:'notification-user',
    component: NotificationUserComponent
  },
  {
    path:'block',
    component: BlockComponent
  },
  {
    path:'admin-login',
    component: AdminLoginComponent
  },
  {
    path:'complete-training-user',
    component: CompleteTrainingUserComponent
  },
  {
    path:'training-in-progress-user',
    component: TrainingInProgressUserComponent
  },
  {
    path:'payment-user',
    component:  PaymentUserComponent
  }
  
  
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
