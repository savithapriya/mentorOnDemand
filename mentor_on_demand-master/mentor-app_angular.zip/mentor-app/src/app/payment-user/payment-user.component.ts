import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-user',
  templateUrl: './payment-user.component.html',
  styleUrls: ['./payment-user.component.css']
})
export class PaymentUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
