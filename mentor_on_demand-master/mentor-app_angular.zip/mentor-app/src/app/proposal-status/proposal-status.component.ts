import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proposal-status',
  templateUrl: './proposal-status.component.html',
  styleUrls: ['./proposal-status.component.css']
})
export class ProposalStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  myClickFunction(event) { 
    //just added console.log which will display the event details in browser on click of the button.
    alert("Accepted Successfully!!!!");
    console.log(event);
 }

}
